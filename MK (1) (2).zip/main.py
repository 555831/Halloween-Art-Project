import turtle as trtl
t = trtl.Turtle()
wn = trtl.Screen()
wn.bgcolor("black")
import random as rand


# Draw Box
t.pencolor("orange")
t.fillcolor("orange")
t.penup()
t.setposition(-20,-100)
t.pendown()
t.begin_fill()
for i in range(4):
  t.forward(40)
  t.left(90)
t.end_fill()
t.hideturtle()

# pictures and stuff
def random_index():
  rand.randint(0,9)
def clicked_box():
  pic_list.pop(random_index)

pic_list = []

t.onclick(clicked_box)

wn.mainloop()