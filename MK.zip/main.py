import turtle as trtl

t = trtl.Turtle()
wn = trtl.Screen()
wn.bgpic("giphy.gif")

import random as rand

wn.addshape('giphy.gif')
t.shape('giphy.gif')
#t.setup(width=100,height=100)

# pictures and stuff

pic_list = [
    'pic1.gif', 'pic2.gif', 'pic3.gif', 'pic4.gif', 'pic5.gif', 'pic6.gif',
    'pic7.gif', 'pic8.gif', 'pic9.gif', 'pic10.gif'
]

#global new_index
#new_index = 0
#global new_image
#new_image = 0


def clicked_box(x, y):
    #global new_index
    new_index = rand.randint(0,9)
    print(new_index)
    #global new_image
    wn.addshape(pic_list[new_index])
    t.shape(pic_list[new_index])


t.onclick(clicked_box)

wn.mainloop()
